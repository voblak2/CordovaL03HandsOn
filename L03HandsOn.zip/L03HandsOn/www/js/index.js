/* var app = {
    // Application Constructor
    initialize: function() {
        document.getElementById(
            "btn").addEventListener('click', app.takePhoto);
    },
    onDeviceReady: function() {
        this.receivedEvent('deviceready');
    },
} */
 /* var app = {
	initialize: function() {
		document.addEventListener(
			'deviceready',
			this.onDeviceReady.bind(this),
			false
		)
	},
	onDeviceReady: function() {
		console.log('device ready');
	}
} */

var app = {
  initialize: function() {
    document.addEventListener("deviceready", onDeviceReady, false);
    function onDeviceReady() {
        console.log("navigator.geolocation works well");
    }
}
}


app.initialize();
var pictureOutput = document.getElementById('pictureOutput');
var coordsOutput = document.getElementById('coordsOutput');
var Latitude;
var Longitude;
    //Take a picture!
    takePhoto = function() {
        console.log("Button Clicked!");
        navigator.camera.getPicture(app.onSuccess, app.onFail, {
          quality: 50,
          destinationType: Camera.DestinationType.DATA_URL
        });
        function takePicture() {
    navigator.geolocation.getCurrentPosition(onGeoSuccess, onGeoError, {
        enableHighAccuracy: true
    })
}
        }
    
       onSuccess = function(imageData) {
          var image = document.getElementById("photo");
          image.src = "data:image/jpeg;base64," + imageData;
        }

        onFail = function(message) {
          alert("Failed because: " + message);
        }
    
var onGeoSuccess = function(position) {
    Latitude = position.coords.latitude;
    Longitude = position.coords.longitude;
    navigator.camera.getPicture(onSuccess, onFail);
}

// Geo error callback
function onGeoError(error) {
	console.log(error.message)
}


app.initialize();